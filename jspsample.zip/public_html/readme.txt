0. Place the entire folder public_html under your home directory on
georgia.eng.utah.edu (ssh log in with your CADE id).

1. Compile the java code in WEB-INF/classes: javac cs5530/*.java

2. Send your CADE id to the TAs (cc both of them in your email)

3. Edit the web.xml in WEB-INF; replace Your Name with your first name
and last name.

4. Access your homepage via http://georgia.eng.utah.edu:8080/~yourcadeid
